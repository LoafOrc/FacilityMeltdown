# Facility Meltdown

The apparatus was a vital part of the upkeep of the facility's nuclear reactor - and you just took it out.

With the facility meltdown mod the appartus has a lot more risk attached to it. When you take it out the entire facility spirals into a self destruction sequence! You'll have 2 minutes to escape and take off before you get vaporized.

This mod is *mostly* networked. Take a look at the known isuses if you have a problem, otherwise join the [lethal company modding discord](https://discord.gg/lcmod) and find the FacilityMeltdown thread and report it there!

## Known Issues
 - Having a player join late via a mod like LateCompany and having that player pick up a apparatus causes the music to start.
 - Mobs spawned during the meltdown sequence only spawn for the host and do not show for other players.